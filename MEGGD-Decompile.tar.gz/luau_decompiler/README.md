# Luau Bytecode Decompiler

A standalone C++ reader, disassembler, and (in progress) decompiler for
[Luau](https://github.com/luau-lang/luau) bytecode -- the compiled format
Roblox's Luau compiler (`luau-compile`) produces from `.lua`/`.luau` source.

This operates purely on bytecode you already have (a file on disk, or a
buffer in memory). It does **not** depend on, and will not gain, any
executor/injection functionality (UNC-style APIs like `getscriptbytecode`,
`hookfunction`, etc.) for pulling bytecode out of a running game -- it's a
static analysis tool, not a game-exploit tool.

## Status

| Component | Status |
|---|---|
| `bytecode_format` | Done -- opcode table, encoding modes, constant tags, matching the official Luau ISA |
| `bytecode_reader` | Done -- full binary parser, validated against real `luau-compile` output |
| `disassembler` | Done -- human-readable instruction listing with resolved constants/imports/labels |
| `expr_tracker` | Done -- symbolic per-register expression builder (turns instructions into an expression/statement IR) |
| structurizer | Not started -- CFG -> structured if/while/for/repeat recovery |
| code printer | Not started -- IR -> Luau-like source text |

The reader and disassembler have been round-trip tested against a locally
built copy of the official `luau-compile` (from `luau-lang/luau`), covering
if/elseif/else, numeric/generic `for`, `while`, `repeat...until`,
`break`/`continue`, closures/upvalues, metatable-based OOP, method calls,
and varargs/multiple-return propagation.

## Building

Requires a C++17 compiler (g++/clang++).

```sh
g++ -std=c++17 -O2 -Iinclude src/*.cpp -o luaudec
```

(A proper CLI entry point / Makefile will be added alongside the
structurizer and code printer.)

## Layout

```
include/    public headers
src/        implementation + (temporary) smoke-test driver
```
